 import SwiftUI
 
 struct ContentView: View {
    @State private var willMoveToNextScreen = false
    
    var body: some View {
        ZStack {
            Image("opening")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
            VStack {
                Spacer()
                Image("title")
                    .resizable()
                    .frame(width: 314, height: 117)
                    .padding(.bottom, 150)
                    .padding(.leading, 40)
                Spacer()
                
                Button(action: { willMoveToNextScreen = true },
                       label: {
                        Image("start")
                            .resizable()
                            .frame(width: 104, height: 56)
                            .padding(.trailing, 500)
                       })
                Spacer()
            }
        }.navigate(to: ChooseMode(), when: $willMoveToNextScreen)
    }
 }
 
 // CHOOSE MODE VIEW
 struct ChooseMode: View {
    @StateObject var Game = serveTable()
    @StateObject var lead = leaderboard()
    @State private var change = false
    
    var body: some View {
        ZStack {
            Image("mode")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                Spacer()
                Image("modeTitle")
                    .resizable()
                    .frame(width: 342, height: 57)
                Spacer()
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        change = true
                        Game.setMode(level: "easy")
                    },
                    label: {
                        Image("easy")
                            .resizable()
                            .frame(width: 104, height: 56)
                    })
                    Spacer()
                    Button(action: {
                        change = true
                        Game.setMode(level: "medium")
                    },
                    label: {
                        Image("medium")
                            .resizable()
                            .frame(width: 155, height: 56)
                    })
                    
                    Spacer()
                    Button(action: {
                        change = true
                        Game.setMode(level: "hard")
                        
                    },
                    label: {
                        Image("hard")
                            .resizable()
                            .frame(width: 104, height: 56)
                    })
                    Spacer()
                }
                Spacer()
            }
        }.navigate(to: Recipe(), when: $change)
        .environmentObject(Game)
        .environmentObject(lead)
    }
 }
 
 // RECIPE VIEW
 struct Recipe: View {
    @EnvironmentObject var Game: serveTable
    @State private var move = false
    
    var body: some View {
        var _ = Game.newRecipe()
        
        ZStack {
            Image("recipeBackground")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
            
            VStack {
                HStack {
                    Image("orderNum")
                        .resizable()
                        .frame(width: 105, height:25)
                    
                    Text(String(Game.count))
                        .bold()
                        .font(.system(size: 30))
                        .padding(.bottom, 2)
                    
                    Spacer()
                    
                    Image("totalOrders")
                        .resizable()
                        .frame(width: 168, height: 25)
                    
                    Text(String(Game.people))
                        .bold()
                        .font(.system(size: 30))
                        .padding(.bottom, 2)
                    
                }.padding(.leading, 20)
                .padding(.trailing, 20)
                .padding(.top, 50)
                
                Image("recipeTitle")
                    .resizable()
                    .frame(width: 101, height: 35)
                    .padding(.bottom, -30)
                
                Text(Game.printRecipe())
                    .bold()
                    .font(.system(size: 25))
                Spacer()
                
                Group {
                    Button(action: {
                        move = true
                        Game.personCounter()
                    },
                    label: {
                        Image("start").resizable()
                            .frame(width: 104, height: 56)
                    })
                    Spacer()
                }
            }
        }.navigate(to: PlayGame(), when: $move)
    }
 }
 
 // PLAY GAME VIEW
 struct PlayGame: View {
    @EnvironmentObject var Game: serveTable
    @EnvironmentObject var lead:leaderboard
    @State private var moveEnd = false
    @State private var moveRecipe = false
    @State private var go:Bool = true
    //TIMER VARIABLES
    @State var isTimerRunning = false
    @State private var startTime =  Date()
    @State private var timerString = "0.00"
    @State private var timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Image("kitchen")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
            
            VStack {
                HStack {
                    Image("timer")
                        .resizable()
                        .frame(width: 66, height: 55)
                        .padding(.leading, 25)
                        .padding(.top, 5)
                    
                    Text(self.timerString)
                        .font(Font.system(.largeTitle, design: .monospaced))
                        .onReceive(timer) { _ in
                            if self.isTimerRunning {
                                timerString = String(format: "%.2f", (Date().timeIntervalSince(self.startTime)))
                            }
                        }
                    Spacer()
                    
                    Button(action: {
                        self.stopTimer()
                        Game.updateTableScore(pattyScore: Game.calcPattyScore(), timeScore: Game.calcTimeScore(time:timerString))
                        if Game.count > Game.people {
                            moveEnd = true
                            lead.updateLeaderboard(score: Game.totalTableScore)
                        }
                        else
                        { moveRecipe = true }
                        
                        Game.order = [""]
                    },
                    label: {
                        Image("done")
                            .resizable()
                            .frame(width:  104,height: 56)
                            .padding(.trailing, 30)
                    })
                }
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                
                Image("plate")
                    .resizable()
                    .frame(width: 342, height: 57)
                
                Spacer()
                HStack {
                    Button( action: {
                        Game.addToOrder(ingredient: "Bottom Bun")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("bottomBunButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("bottomBun")
                        //                                        .resizable()
                        //                                        .frame(width: 238, height: 77)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Cheese")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("cheeseButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("cheese")
                        //                                        .resizable()
                        //                                        .frame(width: 249, height: 79)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Ham")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("hamButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("ham")
                        //                                        .resizable()
                        //                                        .frame(width: 220, height: 52)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Lettuce")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("lettuceButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("lettuce")
                        //                                        .resizable()
                        //                                        .frame(width: 250, height: 69)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Onions")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("onionButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("onion")
                        //                                        .resizable()
                        //                                        .frame(width: 243, height: 75)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Patty")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("pattyButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("patty")
                        //                                        .resizable()
                        //                                        .frame(width: 241, height: 92)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Pickles")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        
                        Image("picklesButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("pickles")
                        //                                        .resizable()
                        //                                        .frame(width: 197, height: 66)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Tomatoes")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("tomatoButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("tomato")
                        //                                        .resizable()
                        //                                        .frame(width: 232, height: 69)
                        //                                }
                    })
                    
                    Button(action: {
                        Game.addToOrder(ingredient: "Top Bun")
                        if !isTimerRunning
                        {
                            timerString = "0.00"
                            startTime = Date()
                            self.startTimer()
                            self.go = false
                            isTimerRunning.toggle()
                        }
                    },
                    label: {
                        Image("topBunButton")
                            .resizable()
                            .frame(width: 66, height: 72)
                        //                                VStack {
                        //                                    Image("topBun")
                        //                                        .resizable()
                        //                                        .frame(width: 239, height: 120)
                        //                                }
                    })
                }
            }
        }.navigate(to: EndGame(), when: $moveEnd)
        .navigate(to: Recipe(), when: $moveRecipe)
    }
    
    //TIMER METHODS
    func stopTimer() {
        self.timer.upstream.connect().cancel()
    }
    
    func startTimer() {
        self.timer = Timer.publish(every: 0.01, on: .main, in: .common).autoconnect()
    }
 }
 
 // END GAME VIEW
 struct EndGame: View {
    @EnvironmentObject var Game: serveTable
    @EnvironmentObject var lead:leaderboard
    @State private var moveLeaderboard = false
    @State private var playAgain = false
    
    var body: some View {
        ZStack {
            Image("endGame")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                Image("scoreTitle")
                    .resizable()
                    .frame(width: 335, height: 115)
                
                Text(String(Game.totalTableScore))
                    .font(.system(size: 60))
                    .bold()
                
                Spacer()
                
                HStack {
                    Button(action:
                            { moveLeaderboard = true },
                           label: {
                            Image("leaderboardButton")
                                .resizable()
                                .frame(width: 155, height: 56)
                           })
                    
                    Button(action: {
                        playAgain = true
                        Game.resetGame()
                    },
                    label: {
                        Image("playAgain")
                            .resizable()
                            .frame(width: 155, height: 56)
                    })
                }
                Spacer()
            }
        }
        .navigate(to: LeaderBoard(), when: $moveLeaderboard)
        .navigate(to: ChooseMode(), when: $playAgain)
    }
 }
 
 // LEADERBOARD VIEW
 struct LeaderBoard: View {
    @EnvironmentObject var Game: serveTable
    @EnvironmentObject var lead:leaderboard
    @State private var playAgain = false
    
    var body: some View {
        ZStack {
            Image("leaderboard")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
            
            Spacer()
            
            VStack {
                Image("leaderboardTitle")
                    .resizable()
                    .frame(width: 265, height: 40)
                    .padding(.bottom, 50)
                                
                HStack
                {
                    Spacer()
                    Spacer()
                    
                    HStack {
                        Image("1st")
                            .resizable()
                            .frame(width: 50, height: 32)
                        
                        Text(String(lead.leaderboard[0]))
                            .foregroundColor(Color.white)
                            .bold()
                            .font(.system(size: 30))
                    }
                    
                    Spacer()
                    
                    HStack {
                        Image("2nd")
                            .resizable()
                            .frame(width: 66, height: 30)
                        
                        Text(String(lead.leaderboard[1]))
                            .foregroundColor(Color.white)
                            .bold()
                            .font(.system(size: 30))
                    }
                    
                    Spacer()
                    Spacer()
                }
                
                HStack
                {
                    Spacer()
                    Spacer()
                    
                    HStack {
                        Image("3rd")
                            .resizable()
                            .frame(width: 58, height: 32)
                        
                        Text(String(lead.leaderboard[2]))
                            .foregroundColor(Color.white)
                            .bold()
                            .font(.system(size: 30))
                    }
                    
                    Spacer()
                    
                    HStack {
                        Image("4th")
                            .resizable()
                            .frame(width: 54, height: 32)
                        
                        Text(String(lead.leaderboard[3]))
                            .foregroundColor(Color.white)
                            .bold()
                            .font(.system(size: 30))
                    }
                    
                    Spacer()
                    
                    HStack {
                        Image("5th")
                            .resizable()
                            .frame(width: 56, height: 32)
                        
                        Text(String(lead.leaderboard[4]))
                            .foregroundColor(Color.white)
                            .bold()
                            .font(.system(size: 30))
                    }
                    
                    Spacer()
                    Spacer()
                }
               
                    Button(action: {
                        playAgain = true
                        Game.resetGame()
                    },
                    label: {
                        Image("playAgain")
                            .resizable()
                            .frame(width: 129, height: 47)
                            .padding(.top, 50)
                    })
                }
            Spacer()
        }.navigate(to: ChooseMode(), when: $playAgain)
    }
 }
 
 //MAIN CLASS
 class serveTable:ObservableObject {
    var mode:String
    var totalTableScore:Int
    var people:Int
    //VARIABLES THAT UPDATE FOR EACH NEW PERSON
    var order:Array<String>
    var recipe:Array<String>
    var count:Int
    
    init() {
        self.mode = "easy"
        self.totalTableScore = 0
        self.order = [""]
        self.recipe = [""]
        self.count = 1
        self.people = 0
    }
    
    func numPpl() -> Int {
        switch mode
        {
        case "hard":
            return 12
        case "medium":
            return 8
        default:
            return 4
        }
    }
    
    func setMode(level:String) {
        self.mode = level
        self.people = numPpl()
    }
    
    func addToOrder(ingredient:String) {
        order.append(ingredient)
    }
    
    func newRecipe() -> Array<String> {
        recipe = ["Bottom Bun", "Patty"]

        let ingredientList: Array<String> = ["Cheese", "Lettuce", "Tomatoes", "Pickles", "Onions", "Ham"]
        
        let numI = numIngredients()
        if numI == 1 {
            let randIndex:Int = Int.random(in: 0...5)
            recipe.append(ingredientList[randIndex])
        }
        else {
            for _ in 1...numI {
                let randIndex:Int = Int.random(in: 0...5)
                recipe.append(ingredientList[randIndex])
            }
        }
        
        recipe.append("Top Bun")
        return recipe
    }
    
    func numIngredients() -> Int {
        switch mode {
        case "hard":
            return Int.random(in: 1...6)
        case "medium":
            return Int.random(in: 1...4)
        default:
            return Int.random(in: 1...2)
        }
    }
    
    func personCounter() {
        self.count = self.count + 1
    }
    
    func updateTableScore(pattyScore:Int, timeScore:Int) {
        print(pattyScore)
        print(timeScore)
        totalTableScore = totalTableScore + pattyScore + timeScore
        print(totalTableScore)
    }
    
    func calcPattyScore() -> Int {
        print("Recipe: ")
        printArray(arr: recipe)
        print("Order: ")
        printArray(arr: order)
        
        var numIngred:Int = recipe.count
        let total:Int = numIngred + 1
        print("\nnumIngred: " + String(numIngred))
        print("\ntotal " + String(total))
        
        let nTop:Int = countIngredient(list: recipe, ingredient: "Top Bun")
        let nTopInO:Int = countIngredient(list: order, ingredient: "Top Bun")
        if nTop != nTopInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nChee:Int = countIngredient(list: recipe, ingredient: "Cheese")
        let nCheeInO:Int = countIngredient(list: order, ingredient: "Cheese")
        if nChee != nCheeInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nLett:Int = countIngredient(list: recipe, ingredient: "Lettuce")
        let nLettInO:Int = countIngredient(list: order, ingredient: "Lettuce")
        if nLett != nLettInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nToma:Int = countIngredient(list: recipe, ingredient: "Tomatoes")
        let nTomaInO:Int = countIngredient(list: order, ingredient: "Tomatoes")
        if nToma != nTomaInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nPick:Int = countIngredient(list: recipe, ingredient: "Pickles")
        let nPickInO:Int = countIngredient(list: order, ingredient: "Pickles")
        if nPick != nPickInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nHam:Int = countIngredient(list: recipe, ingredient: "Ham")
        let nHamInO:Int = countIngredient(list: order, ingredient: "Ham")
        if nHam != nHamInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nOnio:Int = countIngredient(list: recipe, ingredient: "Onions")
        let nOnioInO:Int = countIngredient(list: order, ingredient: "Onions")
        if nOnio != nOnioInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nPatt:Int = countIngredient(list: recipe, ingredient: "Patty")
        let nPattInO:Int = countIngredient(list: order, ingredient: "Patty")
        if nPatt != nPattInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        let nBott:Int = countIngredient(list: recipe, ingredient: "Bottom Bun")
        let nBottInO:Int = countIngredient(list: order, ingredient: "Bottom Bun")
        if nBott != nBottInO
        { numIngred = numIngred - 1 }
        print("\nnumIngred: " + String(numIngred))
        
        var go:Bool = true
        var index:Int = 0
        var count:Int = 0
        
        order.remove(at: 0)
        print("Recipe count: " + String(recipe.count))
        print("Order count: " + String(order.count))
        
        if recipe.count == order.count {
            while go && index < recipe.count {
                if recipe[index] != order[index] {
                    go = false
                    count = count + 1
                }
                
                print("recipe ingred: " + recipe[index])
                print("order ingred: " + order[index])
                print(" Count: " + String(count))
                
                index = index + 1
            }
        }
        
        if count == 0 {
            numIngred = numIngred + 1
        }
        print("\nnumIngred: " + String(numIngred))
        
        let scoreD:Double = (Double (numIngred) / Double (total)) * 100
        let scoreI:Int = Int(scoreD)
        print("\nScore: " + String(scoreI))
        return scoreI;
    }
    
    func countIngredient(list:Array<String>, ingredient:String) -> Int {
        var count:Int = 0
        list.forEach {
            ingred in
            if ingred == ingredient {
                count = count + 1
            }
        }
        return count
    }
    
    func calcTimeScore(time:String) -> Int {
        
        let seconds:Double = (time as NSString).doubleValue
        print(String(seconds))
        if seconds < 3.00
        { return 100 }
        else if seconds >= 3 && seconds < 6
        { return 80 }
        else if seconds >= 6 && seconds < 9
        { return 60 }
        else if seconds >= 9 && seconds < 12
        { return 40 }
        else if seconds >= 12 && seconds < 15
        { return 20 }
        else
        { return 5 }
    }
    
    func printRecipe() -> String {
        var recipeS:String = ""
        var counter:Int = 1
        recipe.forEach { ingredient in
            recipeS = recipeS + "\n" + String(counter) + ". " + ingredient
            counter = counter + 1
        }
        return recipeS
    }
    
    func printArray(arr:Array<String>) {
        arr.forEach {
            x in
            print(x + " ")
        }
    }
    
    func resetGame() {
        self.mode = "easy"
        self.totalTableScore = 0
        self.order = [""]
        self.recipe = [""]
        self.count = 1
        self.people = 0
    }
 }
 
 //LEADERBOARD CLASS
 class leaderboard:ObservableObject {
    var leaderboard:Array<Int>
    
    init() {
        leaderboard = [0, 0, 0, 0, 0]
    }
    
    func updateLeaderboard(score:Int) {
        
        if score > leaderboard[0]
        {
            leaderboard.insert(score, at: 0)
            leaderboard.removeLast()
        }
        
        else if score > leaderboard[1]
        {
            leaderboard.insert(score, at: 1)
            leaderboard.removeLast()
        }
        
        else if score > leaderboard[2]
        {
            leaderboard.insert(score, at: 2)
            leaderboard.removeLast()
        }
        
        else if score > leaderboard[3]
        {
            leaderboard.insert(score, at: 3)
            leaderboard.removeLast()
        }
        
        else if score > leaderboard[4]
        {
            leaderboard.insert(score, at: 4)
            leaderboard.removeLast()
        }
    }
 }
 
 extension View {
    func navigate<NewView: View>(to view: NewView, when binding: Binding<Bool>) -> some View {
        NavigationView {
            ZStack {
                self
                    .navigationBarTitle("")
                    .navigationBarHidden(true)
                
                NavigationLink(
                    destination: view
                        .navigationBarTitle("")
                        .navigationBarHidden(true),
                    isActive: binding) {
                    EmptyView()
                }
            }
        }
    }
 }
 
 
 // CODE DUMP
 //    func Play() //need to revisit
 //    //numPpl()
 //    //loop each person at table:
 //    //        1) generate new recipe - set to var userOrder
 //    //        2) user makes patty - when ingredient button pressed updates order array - set to var recipe          (button action:addToOrder) --LOOP UNTIL DONE BUTTON PRESSED
 //    //        3) calcPattyScore() and calcTimeScore() --> update total table score - calcTableScore()
 //    //        4) updateLeaderBoard()
 //    {
 //        var totalTableScore:Int = 0
 //        for _ in 1...people
 //        {
 //            let recipe:Array<String> = newRecipe()
 //            let pattyS = calcPattyScore(recipe: recipe, userOrder:order)
 //            let timeS = calcTimeScore()
 //            totalTableScore = updTableScore(pattyScore: pattyS, timeScore: timeS)
 //        }
 //        updateLeaderBoard(tableScore: totalTableScore)
 //    }
 
 //        func doneButton()
 //        {
 //            buttonDone = true
 //        }
 
 //func updateLeaderBoard(tableScore:Int)
 //    //update leaderboard array (CLASS VARIABLE) so shows top 5 highest scores
 //    {
 //    }
 
 // func addToScreen(ingredient:String)
 // {
 //    ZStack{
 //        VStack{
 //            if (ingredient == "bottomBun"){
 //                Image("bottomBun")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "cheese"){
 //                Image("cheese")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "ham"){
 //                Image("ham")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "lettuce"){
 //                Image("lettuce")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "onion"){
 //                Image("onion")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "patty"){
 //                Image("patty")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "pickles"){
 //                Image("pickles")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "tomato"){
 //                Image("tomato")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //            else if (ingredient == "topBun"){
 //                Image("topBun")
 //                    .resizable()
 //                    .frame(width: 132, height: 144)
 //            }
 //        }
 //    }
 // }
 
 // class StopWatch: ObservableObject {
 //     private var sourceTimer: DispatchSourceTimer?
 //     private let queue = DispatchQueue(label: "stopwatch.timer")
 //     private var counter: Int = 0
 //
 //     var stopWatchTime = "00:00:00" {
 //         didSet {
 //             self.update()
 //         }
 //     }
 //
 //     var paused = true {
 //         didSet {
 //             self.update()
 //         }
 //     }
 //
 //     var laps = [LapItem]() {
 //         didSet {
 //             self.update()
 //         }
 //     }
 //
 //     private var currentLaps = [LapItem]() {
 //         didSet {
 //             self.laps = currentLaps.reversed()
 //         }
 //     }
 //
 //     func start() {
 //         self.paused = !self.paused
 //
 //         guard let _ = self.sourceTimer else {
 //             self.startTimer()
 //             return
 //         }
 //
 // //        self.resumeTimer()
 //     }
 //
 //     func pause() {
 //         self.paused = !self.paused
 //         self.sourceTimer?.suspend()
 //     }
 //
 //     func lap() {
 //         if let firstLap = self.laps.first {
 //             let difference = self.counter - firstLap.count
 //             self.currentLaps.append(LapItem(count: self.counter, diff: difference))
 //         } else {
 //             self.currentLaps.append(LapItem(count: self.counter))
 //         }
 //     }
 //
 //     func reset() {
 //         self.stopWatchTime = "00:00:00"
 //         self.counter = 0
 //         self.currentLaps = [LapItem]()
 //     }
 //
 //     func update() {
 //         objectWillChange.send()
 //     }
 //
 //     func isPaused() -> Bool {
 //         return self.paused
 //     }
 //
 //     private func startTimer() {
 //         self.sourceTimer = DispatchSource.makeTimerSource(flags: DispatchSource.TimerFlags.strict,
 //                                                           queue: self.queue)
 //
 //        // self.resumeTimer()
 //     }
 //
 // //    private func resumeTimer() {
 // //        self.sourceTimer?.setEventHandler {
 // //            self.updateTimer()
 // //        }
 // //
 // //        self.sourceTimer?.schedule(deadline: .now(),
 // //                                   repeating: 0.01)
 // //     self.sourceTimer?.resume()
 // //    }
 //
 //     private func updateTimer() {
 //         self.counter += 1
 //
 //         DispatchQueue.main.async {
 //             self.stopWatchTime = StopWatch.convertCountToTimeString(counter: self.counter)
 //         }
 //     }
 // }
 //
 // extension StopWatch {
 //     struct LapItem {
 //         let uuid = UUID()
 //         let count: Int
 //         let stringTime: String
 //
 //         init(count: Int, diff: Int = -1) {
 //             self.count = count
 //
 //             if diff < 0 {
 //                 self.stringTime = StopWatch.convertCountToTimeString(counter: count)
 //             } else {
 //                 self.stringTime = StopWatch.convertCountToTimeString(counter: diff)
 //             }
 //         }
 //     }
 // }
 //
 // extension StopWatch {
 //     static func convertCountToTimeString(counter: Int) -> String {
 //         let millseconds = counter % 100
 //         let seconds = counter / 100
 //         let minutes = seconds / 60
 //
 //         var millsecondsString = "\(millseconds)"
 //         var secondsString = "\(seconds)"
 //         var minutesString = "\(minutes)"
 //
 //         if millseconds < 10 {
 //             millsecondsString = "0" + millsecondsString
 //         }
 //
 //         if seconds < 10 {
 //             secondsString = "0" + secondsString
 //         }
 //
 //         if minutes < 10 {
 //             minutesString = "0" + minutesString
 //         }
 //
 //         return "\(minutesString):\(secondsString):\(millsecondsString)"
 //     }
 // }
 //
 //
 //
