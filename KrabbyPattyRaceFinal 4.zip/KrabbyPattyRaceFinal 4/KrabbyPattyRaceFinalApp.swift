//
//  KrabbyPattyRaceFinalApp.swift
//  KrabbyPattyRaceFinal
//
//  Created by Allison Wu on 5/21/21.
//

import SwiftUI

@main
struct KrabbyPattyRaceFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
